"""
    Title: mccue_myworld.py
    Author: Walter McCue
    Date: 10/25/22
    Description: Exercise 2.3
"""

myName = "Walter"
print("You are now in " + myName + "'s world!")